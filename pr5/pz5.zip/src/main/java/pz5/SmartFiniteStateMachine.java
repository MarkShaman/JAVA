package pz5;

public class SmartFiniteStateMachine extends FiniteStateMachine {

    @Override
    public String processString(String text) {
        this.state = "S";

        for (char ch : text.toCharArray()) {
            if (this.state.equals("F")) {
                continue;
            }

            switch (this.state) {
                case "S":
                    if (ch == 'T') this.state = "1";
                    else this.state = "S";
                    break;

                case "1": // Ми вже знайшли "T"
                    if (ch == 'E') this.state = "2";     // Знайшли "TE" -> йдемо далі
                    else if (ch == 'T') this.state = "1"; // ФІКС: Це нова "T", залишаємось тут
                    else this.state = "S";
                    break;

                case "2": // Ми вже знайшли "TE"
                    if (ch == 'S') this.state = "3";     // Знайшли "TES" -> йдемо далі
                    else if (ch == 'T') this.state = "1"; // ФІКС: Це початок нового слова "T..."
                    else this.state = "S";
                    break;

                case "3": // Ми вже знайшли "TES"
                    if (ch == 'T') this.state = "F";     // Знайшли "TEST" -> Успіх!
                    else if (ch == 'T') this.state = "1"; // Теоретичний кейс, хоча після S зазвичай йде T для фінішу
                    else this.state = "S";
                    break;
            }
        }
        return this.state;
    }
}

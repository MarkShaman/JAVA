
import org.junit.Test;
import pz5.FiniteStateMachine;
import pz5.SmartFiniteStateMachine;

import static org.junit.Assert.assertEquals;


public class FsmTest {

    // Тест для Завдання 1 та 2
    @Test
    public void testBaseFSM() {
        FiniteStateMachine fsm = new FiniteStateMachine();

        String[][] testCases = {
                {"abcTESTabc", "F"},
                {"abcTES", "3"},
                {"abcTE", "2"},
                {"abcT", "1"},
                {"random", "S"},
                {"TEST", "F"},
                {"", "S"}
        };

        for (String[] data : testCases) {
            String input = data[0];
            String expected = data[1];

            assertEquals("Failed on input: " + input,
                    expected,
                    fsm.processString(input));
        }
    }

    // Тест для Завдання 3 (Smart)
    @Test
    public void testSmartFSM_EdgeCases() {
        SmartFiniteStateMachine smartFsm = new SmartFiniteStateMachine();

        String[][] edgeCases = {
                {"TTEST", "F"},
                {"TETEST", "F"}
        };

        for (String[] data : edgeCases) {
            String input = data[0];
            String expected = data[1];

            assertEquals("Smart FSM failed on: " + input,
                    expected,
                    smartFsm.processString(input));
        }
    }
}